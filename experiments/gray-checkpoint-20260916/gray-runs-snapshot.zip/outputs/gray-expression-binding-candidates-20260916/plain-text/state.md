<!-- 本文件由运行器从 state.json 渲染，不要直接编辑；要改状态请改 state.json。 -->

# 运行状态：工具使用说明

- 阶段：`content`
- 原稿：`C:\PPagenT\outputs\gray-expression-binding-candidates-20260916\plain-text.txt`
- 来源：2 条
- 下一步：灰稿状态 awaiting-user-review；等待用户审阅，尚未验收
- 受众：需要选择工具的使用者
- 目标：说明离线工具与在线工具的网络条件差异及共同检索能力

## 来源覆盖

全部来源已被引用。

## 页面

### p1 工具使用说明

- 主张：离线与在线工具：条件不同，均可按名称检索
- 关系：先说明本页为模拟内容，再用同一张表按相同口径比较离线工具与在线工具的网络条件和共同检索能力。
- 内容项：2；来源：s1、s2
- 方案版本：0；产物 rendered-awaiting-review（版本 1）

