import { upsertPageBriefs, validateContent } from './state.mjs';
import { checkItemFidelity } from '../content/source-fidelity.mjs';

const nonempty = value => typeof value === 'string' && value.trim().length > 0;
const TYPES = new Set(['support', 'criterion', 'implementation', 'sequence', 'parallel', 'condition', 'qualification', 'comparison', 'decomposition', 'context']);
const KINDS = new Set(['text', 'diagram', 'flow', 'chart', 'table', 'image']);

export const SEMANTIC_CONTRACT = `你是 PPT 内容规划者。本轮只生成灰稿内容，只输出JSON。
本次契约优先于共享规则中可选解析器的字段。不要生成composition-intent、逐句关系图或坐标，不按原稿标题数量分区。
格式：{schemaVersion:"gray-plan-3",deckBrief:{title,audience,objective},pages:[{pageId:"p1",title:"短标题",claim:"简短上屏主题句，建议二十字左右，不复述全部正文",pagePurpose:"本页解决的问题",narrative:"一句话说明必要的先后、并行、判断或归属关系，无需列每条边",groups:[{id:"g1",role:"本组主要职责",heading:"上屏短标题",importance:"primary|supporting",kind:"text|diagram|flow|chart|table|image",blocks:[{id:"b1",label:"可选上屏子标题，不需要可省略",text:"真实上屏文字",sourceIds:["s1"]}],expression:"非text必填：表达作用",relationship:"非text必填：基本关系",production:"非text必填：制作要求"}]}],planningNotes:"简短后台组织说明"}。
先确定读者要理解的关系及最直接的表达，再形成groups。区域是表达选择的结果，不是原稿段落或角色各占一个文字框。需要共同阅读的动作、条件、尺度或对象可共同组成一个图示/表格组；role说明这个整体在本页的职责。普通列举和清楚的自然文字可选text；关系需要对应、分支、共同作用或层级组织时，选择能承载它的表达，不能用row或两个标题代替。复用《页面组合》的主表达方法；本阶段不执行结构Skill，非text只写已有四项蓝区制作说明，后续制作再按需检索结构。
每组一个主要职责。claim概括主题或判断，正文展开对象、安排与条件，不把同一句建议分别复制到主题、组标题和正文。blocks按阅读顺序；label可省略，只有帮助读者定位职责时才用。heading保持短小。蓝区expression写表达作用，relationship写谁与谁怎样关联，production写可执行的组织要求；三者分工，避免重复复述承载内容。必要关系须在实文组织或蓝区制作说明中可见，仅保留关键词或写在narrative里不等于表达完成。
每个block必须引用来源；所有来源至少被一个block引用，模拟声明也须可见并引用，允许就近融入相关文字，无须单独占区。真实条件与否定不能省略，准则不是已满足的证据，并行准备不是下一阶段。
内容区尺寸由输入给定，主题句在内容区外。排版仅有单主体、横向、纵向、规则网格，空间不够时重新组织或分页。正文22px，组标题26px一行，组内每个可选label与text各自排字，约每行30px，块间距12px。每组70px标题/边距开销；按内容估计，不自己写坐标或强制页数。同组label+text合计不超过400字。保留原稿数字写法。
页面目的、narrative和planningNotes不在灰稿上显示。正文必须能独立让读者理解必要关系，不能依赖后台说明。内部审查理由不要改写成正文：用“同时”“是否”“根据记录”等原稿已有表达保留关系，不额外解释“不是先后步骤”“不是已满足的证据”等审稿规则。原稿的模拟/假设性质属于读者需要的内容，须在实际标题或正文中明示，引用sourceIds不能代替显示。`;

export const SEMANTIC_REVIEW_CONTRACT = `你是灰稿内容与表达审稿人。输入source是原稿，requirements是后台职责与必要关系，visiblePages是程序从实际渲染内容生成的上屏视图。只用visiblePages证明表达已落实；requirements不能作为上屏证据。尚未分配坐标或查看像素图。
逐页核对：事实、条件、否定和模拟性质是否完整；主题与正文是否各有职责；组角色是否通过分项、对应、层级或蓝区制作要求落实；必要关系能否直接读出，而非由读者从两个长段落自行拼接。只有标题改名、主辅标签或并排放置，不证明关系已表达。文字本身组织清楚可以通过，不强制图示；图示/流程/图表/表格/图片在本轮都是蓝区制作说明，不要求实际绘图。
准则是选择尺度，不能充当已验证的证据；并行不能写成先后；条件须对应被约束的行动。不要添加原稿未给出的因果、依赖或效果。引用当前可见文案指出具体缺陷；不能仅因个人偏好、估计容量或未知坐标拒绝。主题概括后正文展开是合法分工，长句机械复述和以后台解释代替组织则须修订。
声明在覆盖内容范围的主题或正文出现一次即可。后台审查解释不得进入灰区正文；蓝区制作要求可以说明关系组织与绘制要求。若有reviewFeedback，检查是否实质解决。
只输出JSON：{accepted:boolean,issues:[{pageId,sourceIds,problem,requiredRevision}],coverage:"逐页引用visiblePages中的具体措辞或组织，说明它怎样承担职责和关系；不能仅复述requirements",limits:"未看灰稿像素图，不能确认视觉可读性"}。`;

export const LAYOUT_CONTRACT = `你是页面基础排版选择者。内容已检查，不再判断因果或重写内容，只选择空间组合。
只输出JSON：{pages:[{pageId,layout:{type:"single|row|column|grid",weights:[2,1],columns:2}}]}。
每页必须出现，页序不变。single只用于一个组；row横向分栏，可用weights分配宽度（顺序对应groups）；column上下安排，按实文自然高度；grid用于同等角色的规则网格，columns是列数。weights只在row可用；columns只在grid可用。没有坐标、字号、正文或新分组。程序会按真实文字容量求区域。
按阅读顺序安排全部组，不按角色硬编码左右。少量内容无需拉满整页；主次通过适当的空间份额与原有标题层级体现。对同一内容选择合适基础组合，不强制结构图，不为了变化使用网格。若确实需要改写或拆页，返回{needsReplan:true,reason:"具体问题"}。`;

export function blockText(block) { return [block.label,block.text].filter(nonempty).join('\n'); }

export function regionBody(item) {
  return item.kind === 'text' ? item.text : `表达作用：${item.expression}\n承载内容：${item.text}\n基本关系：${item.relationship}\n制作要求：${item.production}`;
}

/** One display projection for review, measurement and native rendering. No backstage prose. */
export function grayDisplayBlocks(item) {
  if (item.kind !== 'text' || !item.blocks) return [{text:regionBody(item),bold:false,gapBefore:0}];
  return item.blocks.flatMap((block,index) => [
    ...(block.label ? [{text:block.label,bold:true,gapBefore:index ? 12 : 0}] : []),
    {text:block.text,bold:false,gapBefore:!block.label && index ? 12 : 0},
  ]);
}

export function semanticReviewInput({source,area,plan,reviewFeedback=null}) {
  const pages = semanticPages(plan);
  return {
    source, area, reviewFeedback,
    requirements:plan.pages.map(page=>({pageId:page.pageId,pagePurpose:page.pagePurpose,narrative:page.narrative,
      groups:page.groups.map(group=>({id:group.id,role:group.role,importance:group.importance}))})),
    visiblePages:pages.map(page=>({pageId:page.pageId,claim:page.claim,regions:page.items.map(item=>({
      id:item.id,kind:item.kind,heading:item.heading,body:grayDisplayBlocks(item),
    }))})),
  };
}

/** Compile once from structured copy. Layout never supplies or rewrites content. */
export function semanticPages(plan) {
  return plan.pages.map(page => ({
    pageId: page.pageId, title: page.title, claim: page.claim, relation: 'none',
    semantics: { schemaVersion:plan.schemaVersion, pagePurpose: page.pagePurpose, narrative: page.narrative, relations: page.relations ?? [], readingOrder: page.readingOrder ?? page.groups.map(g=>g.id) },
    items: page.groups.map(group => ({
      id: group.id, role: 'object', semanticRole: group.role, importance: group.importance,
      heading: group.heading, kind: group.kind, blocks: structuredClone(group.blocks),
      text: group.blocks.map(blockText).join('\n'),
      sourceIds: [...new Set(group.blocks.flatMap(block => block.sourceIds))],
      ...(group.kind === 'text' ? {} : { expression: group.expression, relationship: group.relationship, production: group.production }),
    })),
  }));
}

export function semanticPlanFromPages(plan) {
  return {schemaVersion:plan.pages[0]?.semantics?.schemaVersion,deckBrief:plan.deckBrief, pages:plan.pages.map(page=>({
    pageId:page.pageId,title:page.title,claim:page.claim,...page.semantics,
    groups:page.items.map(item=>({id:item.id,role:item.semanticRole,heading:item.heading,importance:item.importance,kind:item.kind,blocks:item.blocks,expression:item.expression,relationship:item.relationship,production:item.production})),
  }))};
}

export function validateSemanticPlan(base, plan) {
  const issues = [];
  const simple = plan?.schemaVersion === 'gray-plan-3';
  const fail = (code, pageId, message) => issues.push({ code, pageId, message });
  try {
    if (!plan?.deckBrief || !Array.isArray(plan.pages) || !plan.pages.length || plan.pages.length > 100) throw new Error('缺少 deckBrief/pages 或页数超出1..100');
    const pageIds = new Set();
    const sources = new Map(base.sources.map(source => [source.id, source.text]));
    for (const page of plan.pages) {
      if (!nonempty(page.pageId) || pageIds.has(page.pageId)) throw new Error('pageId 缺失或重复');
      pageIds.add(page.pageId);
      for (const key of ['title', 'claim', 'pagePurpose', 'narrative']) if (!nonempty(page[key])) fail('missing-page-semantics', page.pageId, key);
      if (page.composition || !Array.isArray(page.groups) || !page.groups.length) throw new Error('语义阶段须有groups且不得有composition');
      const nodes = new Set(['$claim']);
      for (const group of page.groups) {
        if (!nonempty(group.id) || nodes.has(group.id)) throw new Error('组/块ID缺失或重复');
        nodes.add(group.id);
        if (![group.role, group.heading].every(nonempty) || !KINDS.has(group.kind) || !['primary','supporting'].includes(group.importance)) throw new Error('组的职责、标题、媒介或权重缺失');
        if (group.kind !== 'text' && ![group.expression,group.relationship,group.production].every(nonempty)) throw new Error('蓝区缺少制作说明');
        if (!Array.isArray(group.blocks) || !group.blocks.length) throw new Error('组缺少内部blocks');
        for (const block of group.blocks) {
          if (!nonempty(block.id) || nodes.has(block.id)) throw new Error('组/块ID缺失或重复');
          nodes.add(block.id);
          if (!(simple ? nonempty(block.text) && (block.label === undefined || typeof block.label === 'string') : [block.role,block.label,block.text].every(nonempty)) || !Array.isArray(block.sourceIds) || !block.sourceIds.length || block.sourceIds.some(id => !sources.has(id))) throw new Error('块的角色、文案或来源缺失');
          const fidelity = checkItemFidelity({text:blockText(block),sourceText:block.sourceIds.map(id=>sources.get(id)).join('\n')});
          if (!fidelity.accepted) fail('block-fidelity', page.pageId, `${block.id}: ${JSON.stringify(fidelity.issues)}`);
        }
      }
      if (!simple || page.readingOrder !== undefined) if (!Array.isArray(page.readingOrder) || page.readingOrder.length !== page.groups.length || new Set(page.readingOrder).size !== page.groups.length || page.groups.some(g=>!page.readingOrder.includes(g.id))) throw new Error('readingOrder须恰好包含全部组');
      if (!simple && (!Array.isArray(page.relations) || !page.relations.length)) throw new Error('必须记录真实关系');
      const touched = new Set();
      for (const edge of page.relations ?? []) {
        if (!TYPES.has(edge.type)) throw new Error(`未知关系类型 ${edge.type}，允许：${[...TYPES].join('|')}`);
        if (!nodes.has(edge.from) || !nodes.has(edge.to) || edge.from === edge.to) throw new Error(`关系端点非法 ${edge.from} -> ${edge.to}；本页节点：${[...nodes].join(',')}`);
        if (!nonempty(edge.meaning)) throw new Error(`关系 ${edge.from} -> ${edge.to} 缺少具体含义`);
        touched.add(edge.from); touched.add(edge.to);
      }
      if (!simple) for (const group of page.groups) {
        if (![group.id,...group.blocks.map(b=>b.id)].some(id=>touched.has(id))) fail('unrelated-group', page.pageId, group.id);
        if (group.blocks.length > 1 && !group.blocks.some(b=>touched.has(b.id))) fail('missing-internal-relation', page.pageId, `${group.id} 有多个blocks，但relations未关联其中任何块；记录真实内部关系，不能只修改叙事文字`);
        for (const block of group.blocks.filter(b=>['condition','qualification'].includes(b.role))) if (!page.relations.some(e=>e.from===block.id && ['condition','qualification'].includes(e.type))) fail('unattached-condition', page.pageId, `${block.id} 必须在relations中以condition或qualification作为from指向被约束对象；不要仅改角色名称绕过`);
      }
      if (!simple && !touched.has('$claim')) fail('unrelated-claim', page.pageId, 'relations数组缺少以$claim为端点的真实关系；必须补齐相应关系记录，仅改写claim正文或planningNotes不能修复此错误');
    }
    const state = upsertPageBriefs({...base, pages:[], phase:'content', deckBrief:plan.deckBrief}, semanticPages(plan));
    issues.push(...validateContent(state).issues);
  } catch (error) { fail('invalid-semantic-plan', undefined, error.message); }
  return {accepted:issues.length===0,issues,coverage:simple ? '内容字段、表达方式、来源覆盖、块级数字/引文及已提供的关系端点；必要关系与限定是否正确仍需语义和实际审阅。' : '结构、引用、块级数字/引文、关系端点及条件归属；不证明语义正确或灰稿可读。'};
}

export function bindSemanticLayout(plan, layout) {
  if (layout?.needsReplan) throw new Error(`需要重新组织：${layout.reason}`);
  if (!layout || Object.keys(layout).some(k=>k!=='pages') || !Array.isArray(layout.pages) || layout.pages.length !== plan.pages.length) throw new Error('排版只能返回同页数的pages');
  const pages = semanticPages(plan);
  for (const [index,page] of pages.entries()) {
    const entry = layout.pages[index];
    if (entry?.pageId !== page.pageId || Object.keys(entry).some(k=>!['pageId','regions'].includes(k)) || !Array.isArray(entry.regions)) throw new Error('排版不能改变页序或内容');
    if (entry.regions.length !== page.items.length || entry.regions.some((r,i)=>r.itemId!==page.semantics.readingOrder[i] || Object.keys(r).some(k=>!['itemId','x','y','width','height','fontSize'].includes(k)))) throw new Error('排版只能按阅读顺序绑定原组ID与几何');
    page.composition = {regions:structuredClone(entry.regions)};
  }
  return {deckBrief:structuredClone(plan.deckBrief),pages,planningNotes:plan.planningNotes};
}
