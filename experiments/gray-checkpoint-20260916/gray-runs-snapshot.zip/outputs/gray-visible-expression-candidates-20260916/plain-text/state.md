<!-- 本文件由运行器从 state.json 渲染，不要直接编辑；要改状态请改 state.json。 -->

# 运行状态：工具使用说明

- 阶段：`content`
- 原稿：`C:\PPagenT\outputs\gray-visible-expression-candidates-20260916\plain-text.txt`
- 来源：2 条
- 下一步：灰稿状态 revision-requested；按检查记录继续规划修订
- 受众：需要选择与使用工具的读者
- 目标：说明离线与在线工具的适用网络条件，并指出两者共有的按名称检索能力

## 来源覆盖

全部来源已被引用。

## 页面

### p1 两种工具的使用条件

- 主张：离线免网络，在线需联网，两者都能按名称检索
- 关系：离线工具和在线工具在联网条件上相互对照，二者共同具备按名称检索的能力
- 内容项：2；来源：s2、s1、s2
- 方案版本：0；产物 rendered-awaiting-review（版本 1）

